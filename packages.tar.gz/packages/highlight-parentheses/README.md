highlight-parentheses.el
========================

Highlight surrounding parentheses in Emacs

[![Build Status](https://travis-ci.org/nschum/highlight-parentheses.el.png?branch=master)](https://travis-ci.org/nschum/highlight-parentheses.el)

Add the following to your .emacs file:

    (require 'highlight-parentheses)

Enable the mode using <kbd>M-x highlight-parentheses-mode</kbd> or by adding it
to a hook.
